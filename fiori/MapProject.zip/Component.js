sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/core/ComponentSupport", // required for UI5 tooling in case of a self-contained build (See https://github.com/SAP/ui5-builder/issues/92)
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("demo.Component", {
		metadata: {
			manifest: "json",
		},

		init: function () {
			UIComponent.prototype.init.apply(this, arguments);
			this.getModel("mapConfig").setDefaultBindingMode("OneWay");
			this.getRouter().initialize();
		},

	});
});